# Login Authentication System

A comprehensive authentication system built with React frontend and Node.js backend, featuring secure JWT-based authentication, password management, and modern security practices.

## Features

- **User Registration & Login** with email/password
- **Password Reset** via email
- **JWT Token Authentication** with refresh tokens
- **Secure Password Hashing** using bcrypt
- **Rate Limiting** to prevent brute force attacks
- **Form Validation** with real-time feedback
- **Responsive Design** with Tailwind CSS
- **Protected Routes** and session management

## Tech Stack

### Frontend
- React.js with hooks
- Tailwind CSS for styling
- React Hook Form for form validation
- Axios for API requests
- React Router for navigation

### Backend
- Node.js with Express.js
- MongoDB with Mongoose
- JWT for authentication
- Bcrypt for password hashing
- Helmet.js for security headers
- Express Rate Limit for rate limiting

## Quick Start

1. **Install dependencies:**
   ```bash
   npm run install-all
   ```

2. **Set up environment variables:**
   - Copy `.env.example` to `.env` in both `server/` and `client/` directories
   - Update the values with your configuration

3. **Start the development servers:**
   ```bash
   npm run dev
   ```

   This will start both the backend server (port 5000) and frontend client (port 3000).

## Project Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── pages/         # Page components
│   │   ├── hooks/         # Custom hooks
│   │   ├── services/      # API services
│   │   └── utils/         # Utility functions
├── server/                # Node.js backend
│   ├── controllers/       # Route controllers
│   ├── middleware/        # Custom middleware
│   ├── models/           # Database models
│   ├── routes/           # API routes
│   └── utils/            # Utility functions
└── package.json          # Root package.json
```

## API Endpoints

- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Reset password
- `GET /api/auth/me` - Get current user profile
- `POST /api/auth/logout` - User logout

## Security Features

- Password hashing with bcrypt
- JWT tokens with expiration
- Rate limiting on authentication endpoints
- Security headers with Helmet.js
- Input validation and sanitization
- CORS configuration

## Environment Variables

### Server (.env)
```
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/auth-system
JWT_SECRET=your-super-secret-jwt-key
JWT_REFRESH_SECRET=your-super-secret-refresh-key
JWT_EXPIRE=24h
JWT_REFRESH_EXPIRE=7d
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
```

### Client (.env)
```
REACT_APP_API_URL=http://localhost:5000/api
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

MIT License - see LICENSE file for details
