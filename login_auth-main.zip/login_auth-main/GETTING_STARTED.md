# Getting Started Guide

## Prerequisites

Before running the application, make sure you have the following installed:

- **Node.js** (version 16 or higher)
- **MongoDB** (running locally or MongoDB Atlas)
- **npm** or **yarn**

## Installation

1. **Clone or download the project**
   ```bash
   cd login-authentication-system
   ```

2. **Install all dependencies**
   ```bash
   npm run install-all
   ```

3. **Set up environment variables**

   **Backend (.env in server/ directory):**
   ```env
   NODE_ENV=development
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/auth-system
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
   JWT_REFRESH_SECRET=your-super-secret-refresh-key-change-this-in-production
   JWT_EXPIRE=24h
   JWT_REFRESH_EXPIRE=7d
   EMAIL_HOST=smtp.gmail.com
   EMAIL_PORT=587
   EMAIL_USER=your-email@gmail.com
   EMAIL_PASS=your-app-password
   CLIENT_URL=http://localhost:3000
   ```

   **Frontend (.env in client/ directory):**
   ```env
   REACT_APP_API_URL=http://localhost:5000/api
   ```

4. **Start MongoDB**
   - If using local MongoDB: `mongod`
   - If using MongoDB Atlas: Make sure your connection string is correct

5. **Run the application**
   ```bash
   npm run dev
   ```

   This will start both the backend server (port 5000) and frontend client (port 3000).

## Usage

1. **Open your browser** and navigate to `http://localhost:3000`

2. **Register a new account:**
   - Click "Register" or "Get Started"
   - Fill in your details (first name, last name, email, password)
   - Check your email for verification link

3. **Login:**
   - Use your email and password
   - Optionally check "Remember me" for extended session

4. **Password Reset:**
   - Click "Forgot your password?" on login page
   - Enter your email address
   - Check your email for reset link

5. **Dashboard:**
   - Access your protected dashboard after login
   - View your profile information and account status

## Features Implemented

### ✅ MVP Features Completed

1. **User Registration**
   - Email and password signup
   - Strong password validation
   - Email uniqueness check
   - Email verification

2. **User Login**
   - Email/password authentication
   - JWT token-based sessions
   - Remember me functionality
   - Account lockout protection

3. **Password Management**
   - Password reset via email
   - Secure password hashing (bcrypt)
   - Password strength validation

4. **Security Features**
   - Password hashing with bcrypt
   - Account lockout after failed attempts
   - Email verification
   - Rate limiting
   - HTTPS support ready
   - JWT token validation

5. **Session Management**
   - JWT access tokens
   - Refresh token rotation
   - Secure cookie storage
   - Automatic token refresh

## API Endpoints

| Method | Endpoint | Description | Access |
|--------|----------|-------------|---------|
| POST | `/api/auth/register` | Register new user | Public |
| POST | `/api/auth/login` | User login | Public |
| POST | `/api/auth/refresh` | Refresh access token | Public |
| POST | `/api/auth/logout` | User logout | Private |
| GET | `/api/auth/me` | Get current user | Private |
| POST | `/api/auth/forgot-password` | Request password reset | Public |
| POST | `/api/auth/reset-password` | Reset password | Public |
| POST | `/api/auth/verify-email` | Verify email address | Public |

## Security Measures

- **Password Security**: bcrypt hashing with salt rounds
- **Token Security**: JWT with expiration and refresh tokens
- **Rate Limiting**: Prevents brute force attacks
- **Input Validation**: Server-side validation for all inputs
- **Account Lockout**: Temporary lockout after failed attempts
- **Email Verification**: Required for account activation
- **HTTPS Ready**: Secure communication support

## Troubleshooting

### Common Issues

1. **MongoDB Connection Error**
   - Ensure MongoDB is running
   - Check connection string in .env file
   - Verify MongoDB port (default: 27017)

2. **Email Not Sending**
   - Check email credentials in .env file
   - For Gmail, use App Password instead of regular password
   - Verify SMTP settings

3. **CORS Issues**
   - Ensure CLIENT_URL in .env matches your frontend URL
   - Check that frontend is running on correct port

4. **Token Issues**
   - Clear browser cookies and localStorage
   - Check JWT secrets in .env file
   - Verify token expiration settings

### Development Tips

- Use browser developer tools to monitor network requests
- Check server console for error messages
- Use MongoDB Compass to inspect database
- Test API endpoints with Postman or similar tools

## Production Deployment

For production deployment:

1. **Update environment variables:**
   - Set `NODE_ENV=production`
   - Use strong, unique JWT secrets
   - Configure production MongoDB URI
   - Set up proper email service

2. **Security considerations:**
   - Enable HTTPS
   - Use environment-specific CORS settings
   - Implement proper logging
   - Set up monitoring and alerts

3. **Performance optimization:**
   - Enable MongoDB indexing
   - Implement caching (Redis)
   - Use CDN for static assets
   - Optimize bundle size

## Support

If you encounter any issues:

1. Check the console logs for error messages
2. Verify all environment variables are set correctly
3. Ensure all dependencies are installed
4. Check MongoDB connection and database access

For additional help, refer to the documentation or create an issue in the project repository.
