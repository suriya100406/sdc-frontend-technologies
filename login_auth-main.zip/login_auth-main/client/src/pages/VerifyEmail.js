import React, { useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const VerifyEmail = () => {
  const { verifyEmail, loading, error } = useAuth();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token');

  useEffect(() => {
    if (token) {
      verifyEmail(token).then((result) => {
        if (result.success) {
          setTimeout(() => {
            navigate('/login');
          }, 3000);
        }
      });
    } else {
      navigate('/');
    }
  }, [token, verifyEmail, navigate]);

  if (!token) {
    return null;
  }

  return (
    <div className="auth-container">
      <div className="auth-form">
        <div className="auth-header">
          <h2 className="auth-title">Email Verification</h2>
          <p className="auth-subtitle">
            {loading ? 'Verifying your email...' : error ? 'Verification failed' : 'Email verified successfully!'}
          </p>
        </div>
        
        <div className="mt-8 text-center">
          {loading && (
            <div className="flex justify-center">
              <div className="loading-spinner h-8 w-8 border-primary-600"></div>
            </div>
          )}
          
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-600">{error}</p>
              <button
                onClick={() => navigate('/')}
                className="btn-primary mt-4"
              >
                Go to Home
              </button>
            </div>
          )}
          
          {!loading && !error && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="text-green-600 mb-4">Your email has been verified successfully!</p>
              <p className="text-gray-600 text-sm">Redirecting to login page...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VerifyEmail;
