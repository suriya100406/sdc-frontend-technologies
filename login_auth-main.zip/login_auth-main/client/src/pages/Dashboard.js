import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const Dashboard = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-6">
              Welcome to your Dashboard
            </h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="card">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Profile Information</h3>
                <div className="space-y-2">
                  <p><span className="font-medium">Name:</span> {user?.firstName} {user?.lastName}</p>
                  <p><span className="font-medium">Email:</span> {user?.email}</p>
                  <p><span className="font-medium">Email Verified:</span> 
                    <span className={`ml-1 ${user?.isEmailVerified ? 'text-green-600' : 'text-red-600'}`}>
                      {user?.isEmailVerified ? 'Yes' : 'No'}
                    </span>
                  </p>
                  <p><span className="font-medium">Member Since:</span> 
                    {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
                  </p>
                </div>
              </div>
              
              <div className="card">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Account Status</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-600">Account Active</span>
                  </div>
                  <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-2 ${user?.isEmailVerified ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                    <span className="text-sm text-gray-600">
                      {user?.isEmailVerified ? 'Email Verified' : 'Email Pending Verification'}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="card">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Quick Actions</h3>
                <div className="space-y-2">
                  <button className="btn-outline w-full text-sm">
                    Update Profile
                  </button>
                  <button className="btn-outline w-full text-sm">
                    Change Password
                  </button>
                  <button className="btn-outline w-full text-sm">
                    Security Settings
                  </button>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <div className="card">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between py-2 border-b border-gray-100">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Account Created</p>
                      <p className="text-xs text-gray-500">
                        {user?.createdAt ? new Date(user.createdAt).toLocaleString() : 'N/A'}
                      </p>
                    </div>
                    <span className="text-xs text-gray-500">System</span>
                  </div>
                  
                  {user?.lastLogin && (
                    <div className="flex items-center justify-between py-2 border-b border-gray-100">
                      <div>
                        <p className="text-sm font-medium text-gray-900">Last Login</p>
                        <p className="text-xs text-gray-500">
                          {new Date(user.lastLogin).toLocaleString()}
                        </p>
                      </div>
                      <span className="text-xs text-gray-500">Login</span>
                    </div>
                  )}
                  
                  {user?.isEmailVerified && (
                    <div className="flex items-center justify-between py-2">
                      <div>
                        <p className="text-sm font-medium text-gray-900">Email Verified</p>
                        <p className="text-xs text-gray-500">Email verification completed</p>
                      </div>
                      <span className="text-xs text-gray-500">Verification</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
