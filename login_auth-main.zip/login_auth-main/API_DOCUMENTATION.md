# API Documentation

## Authentication System API

This document describes the REST API endpoints for the Login Authentication System.

### Base URL
```
http://localhost:5000/api
```

### Authentication
Most endpoints require authentication via JWT token. Include the token in the Authorization header:
```
Authorization: Bearer <your-jwt-token>
```

---

## Endpoints

### 1. User Registration

**POST** `/auth/register`

Register a new user account.

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "password": "SecurePass123!"
}
```

**Validation Rules:**
- `firstName`: Required, 1-50 characters
- `lastName`: Required, 1-50 characters
- `email`: Required, valid email format, unique
- `password`: Required, min 8 characters, must contain uppercase, lowercase, number, and special character

**Response (201):**
```json
{
  "success": true,
  "message": "User registered successfully. Please check your email to verify your account.",
  "data": {
    "user": {
      "id": "64a1b2c3d4e5f6789abcdef0",
      "email": "john.doe@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "isEmailVerified": false
    }
  }
}
```

**Error Response (400):**
```json
{
  "success": false,
  "message": "User already exists with this email"
}
```

---

### 2. User Login

**POST** `/auth/login`

Authenticate user and return JWT tokens.

**Request Body:**
```json
{
  "email": "john.doe@example.com",
  "password": "SecurePass123!",
  "rememberMe": false
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": "64a1b2c3d4e5f6789abcdef0",
      "email": "john.doe@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "isEmailVerified": true,
      "lastLogin": "2023-07-01T10:30:00.000Z"
    },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

**Error Response (401):**
```json
{
  "success": false,
  "message": "Invalid credentials"
}
```

---

### 3. Refresh Token

**POST** `/auth/refresh`

Refresh access token using refresh token.

**Request Body:**
```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Token refreshed successfully",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

---

### 4. User Logout

**POST** `/auth/logout`

Logout user and invalidate refresh token.

**Headers:**
```
Authorization: Bearer <access-token>
```

**Response (200):**
```json
{
  "success": true,
  "message": "Logout successful"
}
```

---

### 5. Get Current User

**GET** `/auth/me`

Get current authenticated user's profile.

**Headers:**
```
Authorization: Bearer <access-token>
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "64a1b2c3d4e5f6789abcdef0",
      "email": "john.doe@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "isEmailVerified": true,
      "lastLogin": "2023-07-01T10:30:00.000Z",
      "createdAt": "2023-07-01T09:00:00.000Z"
    }
  }
}
```

---

### 6. Forgot Password

**POST** `/auth/forgot-password`

Send password reset link to user's email.

**Request Body:**
```json
{
  "email": "john.doe@example.com"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "If an account with that email exists, a password reset link has been sent."
}
```

---

### 7. Reset Password

**POST** `/auth/reset-password`

Reset user password using reset token.

**Request Body:**
```json
{
  "token": "reset-token-from-email",
  "password": "NewSecurePass123!"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Password reset successful"
}
```

**Error Response (400):**
```json
{
  "success": false,
  "message": "Invalid or expired reset token"
}
```

---

### 8. Verify Email

**POST** `/auth/verify-email`

Verify user's email address using verification token.

**Request Body:**
```json
{
  "token": "verification-token-from-email"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Email verified successfully"
}
```

**Error Response (400):**
```json
{
  "success": false,
  "message": "Invalid verification token"
}
```

---

## Error Responses

### Validation Error (400)
```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "email",
      "message": "Please provide a valid email"
    }
  ]
}
```

### Unauthorized (401)
```json
{
  "success": false,
  "message": "Not authorized, no token provided"
}
```

### Forbidden (403)
```json
{
  "success": false,
  "message": "User role user is not authorized to access this route"
}
```

### Not Found (404)
```json
{
  "success": false,
  "message": "Route not found"
}
```

### Rate Limited (429)
```json
{
  "success": false,
  "message": "Too many authentication attempts, please try again later."
}
```

### Server Error (500)
```json
{
  "success": false,
  "message": "Server Error"
}
```

---

## Rate Limiting

- **General API**: 100 requests per 15 minutes per IP
- **Authentication endpoints**: 5 requests per 15 minutes per IP

---

## Security Features

1. **Password Requirements:**
   - Minimum 8 characters
   - At least one uppercase letter
   - At least one lowercase letter
   - At least one number
   - At least one special character

2. **Account Lockout:**
   - Account locked after 5 failed login attempts
   - Lockout duration: 2 hours

3. **Token Expiration:**
   - Access tokens: 24 hours (configurable)
   - Refresh tokens: 7 days (configurable)

4. **Email Verification:**
   - Required for account activation
   - Verification link expires in 24 hours

5. **Password Reset:**
   - Reset link expires in 10 minutes
   - One-time use only

---

## Testing the API

### Using cURL

**Register:**
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@example.com",
    "password": "SecurePass123!"
  }'
```

**Login:**
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john.doe@example.com",
    "password": "SecurePass123!"
  }'
```

**Get Profile:**
```bash
curl -X GET http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer <your-access-token>"
```

### Using Postman

1. Import the API collection
2. Set up environment variables for base URL
3. Use the authentication flow:
   - Register → Login → Get Profile
   - Test password reset flow
   - Test email verification

---

## Database Schema

### User Model
```javascript
{
  email: String (required, unique, lowercase)
  password: String (required, hashed)
  firstName: String (required, 1-50 chars)
  lastName: String (required, 1-50 chars)
  isEmailVerified: Boolean (default: false)
  emailVerificationToken: String (hashed)
  passwordResetToken: String (hashed)
  passwordResetExpires: Date
  loginAttempts: Number (default: 0)
  lockUntil: Date
  lastLogin: Date
  refreshTokens: [{
    token: String,
    createdAt: Date (expires: 7 days)
  }]
  createdAt: Date
  updatedAt: Date
}
```
