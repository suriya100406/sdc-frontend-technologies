const axios = require('axios');

const API_BASE_URL = 'http://localhost:5000/api';

// Test configuration
const testUser = {
  firstName: 'Test',
  lastName: 'User',
  email: 'test@example.com',
  password: 'TestPass123!'
};

let accessToken = '';
let refreshToken = '';

// Helper function to make API calls
const apiCall = async (method, endpoint, data = null, headers = {}) => {
  try {
    const config = {
      method,
      url: `${API_BASE_URL}${endpoint}`,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };
    
    if (data) {
      config.data = data;
    }
    
    const response = await axios(config);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data || { message: error.message }
    };
  }
};

// Test functions
const testRegistration = async () => {
  console.log('\n🧪 Testing User Registration...');
  const result = await apiCall('POST', '/auth/register', testUser);
  
  if (result.success) {
    console.log('✅ Registration successful');
    console.log('   User ID:', result.data.data.user.id);
    console.log('   Email:', result.data.data.user.email);
  } else {
    console.log('❌ Registration failed:', result.error.message);
  }
  
  return result.success;
};

const testLogin = async () => {
  console.log('\n🧪 Testing User Login...');
  const loginData = {
    email: testUser.email,
    password: testUser.password
  };
  
  const result = await apiCall('POST', '/auth/login', loginData);
  
  if (result.success) {
    console.log('✅ Login successful');
    accessToken = result.data.data.accessToken;
    refreshToken = result.data.data.refreshToken;
    console.log('   Access Token:', accessToken.substring(0, 20) + '...');
    console.log('   User:', result.data.data.user.firstName, result.data.data.user.lastName);
  } else {
    console.log('❌ Login failed:', result.error.message);
  }
  
  return result.success;
};

const testGetProfile = async () => {
  console.log('\n🧪 Testing Get Profile...');
  const result = await apiCall('GET', '/auth/me', null, {
    'Authorization': `Bearer ${accessToken}`
  });
  
  if (result.success) {
    console.log('✅ Get profile successful');
    console.log('   User:', result.data.data.user.firstName, result.data.data.user.lastName);
    console.log('   Email Verified:', result.data.data.user.isEmailVerified);
  } else {
    console.log('❌ Get profile failed:', result.error.message);
  }
  
  return result.success;
};

const testRefreshToken = async () => {
  console.log('\n🧪 Testing Token Refresh...');
  const result = await apiCall('POST', '/auth/refresh', { refreshToken });
  
  if (result.success) {
    console.log('✅ Token refresh successful');
    accessToken = result.data.data.accessToken;
    console.log('   New Access Token:', accessToken.substring(0, 20) + '...');
  } else {
    console.log('❌ Token refresh failed:', result.error.message);
  }
  
  return result.success;
};

const testForgotPassword = async () => {
  console.log('\n🧪 Testing Forgot Password...');
  const result = await apiCall('POST', '/auth/forgot-password', {
    email: testUser.email
  });
  
  if (result.success) {
    console.log('✅ Forgot password successful');
    console.log('   Message:', result.data.message);
  } else {
    console.log('❌ Forgot password failed:', result.error.message);
  }
  
  return result.success;
};

const testLogout = async () => {
  console.log('\n🧪 Testing Logout...');
  const result = await apiCall('POST', '/auth/logout', null, {
    'Authorization': `Bearer ${accessToken}`
  });
  
  if (result.success) {
    console.log('✅ Logout successful');
  } else {
    console.log('❌ Logout failed:', result.error.message);
  }
  
  return result.success;
};

const testInvalidCredentials = async () => {
  console.log('\n🧪 Testing Invalid Credentials...');
  const result = await apiCall('POST', '/auth/login', {
    email: testUser.email,
    password: 'wrongpassword'
  });
  
  if (!result.success) {
    console.log('✅ Invalid credentials properly rejected');
    console.log('   Error:', result.error.message);
  } else {
    console.log('❌ Invalid credentials should have been rejected');
  }
  
  return !result.success;
};

const testUnauthorizedAccess = async () => {
  console.log('\n🧪 Testing Unauthorized Access...');
  const result = await apiCall('GET', '/auth/me');
  
  if (!result.success) {
    console.log('✅ Unauthorized access properly rejected');
    console.log('   Error:', result.error.message);
  } else {
    console.log('❌ Unauthorized access should have been rejected');
  }
  
  return !result.success;
};

// Main test runner
const runTests = async () => {
  console.log('🚀 Starting Authentication System Tests');
  console.log('=====================================');
  
  const tests = [
    { name: 'Registration', fn: testRegistration },
    { name: 'Login', fn: testLogin },
    { name: 'Get Profile', fn: testGetProfile },
    { name: 'Token Refresh', fn: testRefreshToken },
    { name: 'Forgot Password', fn: testForgotPassword },
    { name: 'Invalid Credentials', fn: testInvalidCredentials },
    { name: 'Unauthorized Access', fn: testUnauthorizedAccess },
    { name: 'Logout', fn: testLogout }
  ];
  
  let passed = 0;
  let total = tests.length;
  
  for (const test of tests) {
    try {
      const success = await test.fn();
      if (success) passed++;
    } catch (error) {
      console.log(`❌ ${test.name} failed with error:`, error.message);
    }
  }
  
  console.log('\n📊 Test Results');
  console.log('================');
  console.log(`Passed: ${passed}/${total}`);
  console.log(`Success Rate: ${((passed / total) * 100).toFixed(1)}%`);
  
  if (passed === total) {
    console.log('\n🎉 All tests passed! The authentication system is working correctly.');
  } else {
    console.log('\n⚠️  Some tests failed. Please check the server logs and configuration.');
  }
};

// Check if server is running
const checkServer = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/health`);
    console.log('✅ Server is running');
    return true;
  } catch (error) {
    console.log('❌ Server is not running. Please start the server first:');
    console.log('   cd server && npm run dev');
    return false;
  }
};

// Run the tests
const main = async () => {
  const serverRunning = await checkServer();
  if (serverRunning) {
    await runTests();
  }
};

main().catch(console.error);
